# -*- coding: utf-8 -*-
"""
Created on Thu Jan 19 21:58:26 2023
Fixation probability plot for evolutionary games
@author: zziya
"""
import json
import matplotlib.pyplot as plt
import numpy as np
N=1000
lam=3.5
mu=6.4
network_type='rrg'
Ks=[4, 8, 12, 16]
Cs=['#FB9489', '#A9DDD4', '#9EC3DB', '#CBC7DE']
Ms=['^','o','+','s']
B=np.arange(1,20,1)
plt.figure(figsize=(8,6))
for k in Ks:
    filename1="rhoc_"+"{:.2f}_".format(lam)+"{:.2f}_".format(mu)+network_type+"_{:d}".format(k)
    filename2="rhod_"+"{:.2f}_".format(lam)+"{:.2f}_".format(mu)+network_type+"_{:d}".format(k)
    f1=open(".\\saves\\{}\\{}.json".format(N, filename1))
    rhoc=json.load(f1)
    f2=open(".\\saves\\{}\\{}.json".format(N, filename2))
    rhod=json.load(f2)
    c=[]
    d=[]
    for b in B:
        c.append(rhoc['{:.2f}'.format(b)])
        d.append(rhod['{:.2f}'.format(b)])
    plt.scatter(B, np.array(c)-np.array(d),s=80, color = Cs[Ks.index(k)],marker=Ms[Ks.index(k)], label = '$k = {:d}$'.format(k))
plt.xlim([0, 20])
plt.ylim([-0.05, 0.05])
plt.plot([0,20], [0,0],c='grey', linestyle='--',lw=2)
plt.legend(fontsize=20)
plt.show()