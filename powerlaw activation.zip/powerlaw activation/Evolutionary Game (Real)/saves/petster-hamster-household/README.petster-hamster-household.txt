Hamsterster households network, part of the Koblenz Network Collection
===========================================================================

This directory contains the TSV and related files of the petster-hamster-household network: 
<k>=5.12

More information about the network is provided here: 
http://konect.cc/networks/petster-hamster-household

Files: 
    meta.petster-hamster-household -- Metadata about the network 
    out.petster-hamster-household -- The adjacency matrix of the network in whitespace-separated values format, with one edge per line
      The meaning of the columns in out.petster-hamster-household are: 
        First column: ID of from node 
        Second column: ID of to node
        Third column (if present): weight or multiplicity of edge
        Fourth column (if present):  timestamp of edges Unix time


Use the following References for citation:

@MISC{konect:2018:petster-hamster-household,
    title = {Hamsterster households network dataset -- {KONECT}},
    month = jan,
    year = {2018},
    url = {http://konect.cc/networks/petster-hamster-household}
}


@inproceedings{konect,
	title = {{KONECT} -- {The} {Koblenz} {Network} {Collection}},
	author = {Jérôme Kunegis},
	year = {2013},
	booktitle = {Proc. Int. Conf. on World Wide Web Companion},
	pages = {1343--1350},
	url = {http://dl.acm.org/citation.cfm?id=2488173},
	url_presentation = {https://www.slideshare.net/kunegis/presentationwow},
	url_web = {http://konect.cc/},
	url_citations = {https://scholar.google.com/scholar?cites=7174338004474749050},
}

@inproceedings{konect,
	title = {{KONECT} -- {The} {Koblenz} {Network} {Collection}},
	author = {Jérôme Kunegis},
	year = {2013},
	booktitle = {Proc. Int. Conf. on World Wide Web Companion},
	pages = {1343--1350},
	url = {http://dl.acm.org/citation.cfm?id=2488173},
	url_presentation = {https://www.slideshare.net/kunegis/presentationwow},
	url_web = {http://konect.cc/},
	url_citations = {https://scholar.google.com/scholar?cites=7174338004474749050},
}


