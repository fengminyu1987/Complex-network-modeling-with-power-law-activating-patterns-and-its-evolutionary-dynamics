# -*- coding: utf-8 -*-
"""
Created on Tue Sep 21 23:23:49 2021

@author: 86150
"""
import networkx as nx
import warnings
import numpy as np
warnings.filterwarnings("ignore")
import matplotlib.pyplot as plt
import random
import json
tmax=15000
lam=0.005
interval=0.0005
MU=list(np.arange(interval,0.03+interval,interval))
Ns=[2000,4000,6000]
#初始网络
#G=nx.generators.lattice.grid_graph(dim=(1, 30, 30))
colors=["red","green","blue"]
markers=["o","^","s"]
savers={}
for N in Ns:
    result=[]
    G=nx.watts_strogatz_graph(N,20,0.2)
    for mu in MU:
        #初始State改变时间
        confi=[]
        next_change={}
        #State中1代表可见的(Visible)，0代表不可见的(Invisible)
        state={}
        #初始化
        for i in G.nodes:
            next_change[i]=random.expovariate(mu)
            state[i]=1
        visible=N
        invisible=0
        #当前时间
        tnow=0
        #开始迭代
        flag=0
        size=0
        count=0
        cmd=10000
        while tnow<=tmax:
            changer=min(next_change.items(),key=lambda x: x[1])[0]
            tnow=next_change[changer]
            if state[changer]==1:
                state[changer]=0
                next_change[changer]+=random.expovariate(lam)
                invisible+=1
                visible-=1
            elif state[changer]==0:
                state[changer]=1
                next_change[changer]+=random.expovariate(mu)
                visible+=1
                invisible-=1
            if (tnow>=cmd):
                cmd+=tmax
                flag=1
            if (flag==1):
                size+=visible
                confi.append(visible)
                count+=1
            print("\r {}={:.3f}, {}={:.4f}, N(0)={:d}, t:{:.2f}/{:.2f}     ".format(chr(955),lam,chr(956),mu,N,tnow,tmax),end="")
        size/=count
        result.append(size)
    savers["{:d}".format(N)]=result
    plt.plot(MU,result,color=colors[Ns.index(N)],markeredgewidth=1.25,marker=markers[Ns.index(N)],markeredgecolor="black",markersize=14,lw=1,label="$N(0)={:d}$".format(N))
save=json.dumps(savers)
f=open('.\{:.3f}.json'.format(lam),'w')
f.write(save)
plt.figure(figsize=(10,6))
#画出理论解的折线
MU=list(np.arange(interval,0.03+interval,interval))
def Nt(lam,MU,N):
    NT=[]
    for i in MU:
        NT.append(lam*N/(lam+i))
    return NT
for N in Ns:
    plt.plot(MU,Nt(lam,MU,N),linestyle='--',linewidth=3,color="purple")
plt.plot(MU,Nt(lam,MU,Ns[0]),linestyle='--',linewidth=3,color="purple",label="$Theoretical$")
plt.xticks(fontsize=25)
plt.yticks(fontsize=25)
plt.legend(fontsize=20)
plt.xlabel("$\mu$",fontsize=25)
plt.ylabel("$N$",fontsize=25)
plt.ylim([0,6000])
plt.xlim([interval,0.030])
plt.savefig("./{:.3f}.pdf".format(lam),dpi=500,bbox_inches='tight')
plt.show()
print("\r Programms ends...                                         ")